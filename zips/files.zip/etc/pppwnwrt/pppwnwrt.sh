#!/bin/sh

# 设置 PS4 的 MAC 地址和网口名称
PS4_MAC="PS4_MAC_ADDRESS"  # 替换为你的 PS4 的 MAC 地址
INTERFACE="INTERFACE_NAME"  # 替换为你的网口名称，如 eth0
FW="PS4_FW_2024"  # 替换为你的具体填写式

# 初始化 PS4 在线状态和注入状态
PS4_ONLINE=false
INJECTED=false

# 主循环
while true; do
    # 检测 PS4 是否在线
    arp -an | grep "$PS4_MAC" > /dev/null

    if [ $? -eq 0 ]; then
        # PS4 在线
        if [ "$PS4_ONLINE" = false ]; then
            # PS4 刚刚重新上线
            PS4_ONLINE=true
            echo "PS4 is online."

            if [ "$INJECTED" = false ]; then
                # 尚未注入，开始注入操作
                echo "Injecting..."
                output=$(pppwn -i "$INTERFACE" --fw "$FW" -s1 /etc/pppwnwrt/stage1_"$FW".bin -s2 /etc/pppwnwrt/stage2_"$FW".bin -a)
                echo "$output"  # 输出命令执行结果，用于调试查看

                # 等待1分30秒（90秒）以确保注入完成
                echo "Waiting 90 seconds to ensure injection completion..."
                sleep 90

                # 检查输出中是否包含 "done"
                if echo "$output" | grep -q "done"; then
                    echo "Injection successful."
                    INJECTED=true  # 设置注入状态为已完成
                    echo "https://github.com/naixue233/PPPwnWRT_naixue233"
                    echo "Coded By naixue233"
                else
                    echo "Injection failed or not yet completed."
                fi
            else
                # 已经注入过了，继续监测状态
                echo "Already injected. Monitoring..."
            fi
        else
            # PS4 已经在线，继续监测状态
            echo "PS4 is online. Continuing to monitor..."
        fi
    else
        # PS4 离线
        if [ "$PS4_ONLINE" = true ]; then
            # PS4 刚刚离线，重置状态
            PS4_ONLINE=false
            echo "PS4 is offline. Waiting for PS4 to come online..."
        else
            # PS4 仍然离线，继续等待
            echo "PS4 is offline. Waiting..."
        fi

        # 重置注入状态为未完成，以便 PS4 下次上线时重新进行注入
        INJECTED=false
    fi

    # 等待30秒后再次检测 PS4 状态
    sleep 30
done
