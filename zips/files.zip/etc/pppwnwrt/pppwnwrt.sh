#!/bin/sh

# 设置网口名称和固件版本
INTERFACE="INTERFACE_NAME"  # 替换为你的网口名称，如 eth0
FW="PS4_FW_2024"  # 替换为你的具体填写式

# 初始化 PS4 在线状态和注入状态
PS4_ONLINE=false
INJECTED=false

# 设置等待时间变量
INJECTION_WAIT_TIME=90  # 注入操作完成后的等待时间（秒）
CHECK_INTERVAL=30  # 检查 PS4 状态的时间间隔（秒）
RETRY_WAIT_TIME=5  # 注入失败后重试等待时间（秒）
ONLINE_WAIT_TIME=1  # 判断在线状态后的等待时间（秒）

# 主循环
while true; do
    # 检测网卡是否有链路（判断物理连接状态）
    if ethtool "$INTERFACE" | grep -q "Link detected: yes"; then
        # 检测到链路，进一步检测是否有流量（判断逻辑连接状态）
        RX_BYTES_BEFORE=$(ifconfig "$INTERFACE" | grep 'RX packets' | awk '{print $5}')
        sleep 5
        RX_BYTES_AFTER=$(ifconfig "$INTERFACE" | grep 'RX packets' | awk '{print $5}')

        if [ "$RX_BYTES_AFTER" -gt "$RX_BYTES_BEFORE" ]; then
            # 网卡有活动流量，判断为 PS4 在线
            if [ "$PS4_ONLINE" = false ]; then
                # PS4 刚刚重新上线
                PS4_ONLINE=true
                echo "PS4 is online."
                sleep "$ONLINE_WAIT_TIME"

                if [ "$INJECTED" = false ]; then
                    # 尚未注入，开始注入操作
                    echo "Injecting..."
                    output=$(pppwn -i "$INTERFACE" --fw "$FW" -s1 /etc/pppwnwrt/stage1_"$FW".bin -s2 /etc/pppwnwrt/stage2_"$FW".bin -a)
                    echo "$output"  # 输出命令执行结果，用于调试查看

                    # 等待设定的时间以确保注入完成
                    echo "Waiting $INJECTION_WAIT_TIME seconds to ensure injection completion..."
                    sleep "$INJECTION_WAIT_TIME"

                    # 检查输出中是否包含 "done"
                    if echo "$output" | grep -q "done"; then
                        echo "Injection successful."
                        INJECTED=true  # 设置注入状态为已完成
                        echo "https://github.com/naixue233/PPPwnWRT_naixue233"
                        echo "Coded By naixue233"
                    else
                        echo "Injection failed or not yet completed."
                        sleep "$RETRY_WAIT_TIME"  # 如果注入失败，等待设定时间后重新尝试
                    fi
                else
                    # 已经注入过了，继续监测状态，但不会再次注入
                    echo "Already injected. Monitoring..."
                fi
            else
                # PS4 已经在线，继续监测状态
                echo "PS4 is online. Continuing to monitor..."
                sleep "$ONLINE_WAIT_TIME"
            fi
        else
            # 网卡没有活动流量，判断为 PS4 离线
            if [ "$PS4_ONLINE" = true ]; then
                # PS4 刚刚离线
                PS4_ONLINE=false
                echo "PS4 is offline. Waiting for PS4 to come online..."
                INJECTED=false  # 重置注入状态，以便 PS4 下次上线时重新进行注入
            else
                echo "PS4 is offline. Waiting..."
            fi
        fi
    else
        # 网卡没有检测到链路，判断为 PS4 离线
        if [ "$PS4_ONLINE" = true ]; then
            # PS4 刚刚离线
            PS4_ONLINE=false
            echo "PS4 is offline. Waiting for PS4 to come online..."
            INJECTED=false  # 重置注入状态，以便 PS4 下次上线时重新进行注入
        else
            echo "PS4 is offline. Waiting..."
        fi
    fi

    # 等待设定的检查间隔时间后再次检测 PS4 状态
    sleep "$CHECK_INTERVAL"
done
